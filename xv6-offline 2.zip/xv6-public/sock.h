
//
// TODO: Define an enumeration to represent socket state.
//
//
// TODO: Define a structure to represent a socket.
//
#define buffer_size 1000
enum sockstate { CLOSED, LISTENING, CONNECTING, CONNECTED };


struct socket{
enum sockstate state;
char buffer[buffer_size];
int local_port;
int remote_port;
char *local_ip;
char *remote_ip;
int ownerProcessID;
int buffer_empty;

};
