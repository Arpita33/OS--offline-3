#include "types.h"
#include "defs.h"
#include "param.h"
#include "spinlock.h"
#include "sock.h"
#include "memlayout.h"
#include "mmu.h"
#include "x86.h"
#include "proc.h"

//
// TODO: Create a structure to maintain a list of sockets
// Should it have locking?
//

struct {
  struct spinlock lock;
  struct socket socket_arr[NSOCK];
 int _ports[NPORT];
} stable;



void
sinit(void)
{
  //
  // TODO: Write any initialization code for socket API
  // initialization.
  //
	initlock(&stable.lock, "stable");
	struct socket *s;

	for(s = stable.socket_arr; s < &stable.socket_arr[NSOCK]; s++)
	{
		s->local_port=-200;
		
	}
	int x;
	for(x=0;x<NPORT;x++)
	{
		stable._ports[x]=0;
	}

}

int
listen(int lport) 
{
	struct socket *s;
	acquire(&stable.lock);

	if(stable._ports[lport]==1)
	{
	   cprintf("Failure due to used port.\n");
	   release(&stable.lock);
	   return E_NOTFOUND;
  	   //goto failure;
  	}
	for(s = stable.socket_arr; s < &stable.socket_arr[NSOCK]; s++)
	{
		if(s->state==CLOSED )
		{
		 	goto success;
		}
	}
cprintf("No more sockets can be opened(limit exceeded)\n");
release(&stable.lock);
return E_FAIL;

success: 
	stable._ports[lport]=1;
	s->state=LISTENING;
	s->local_port=lport;
	s->ownerProcessID=myproc()->pid;	
	sleep(s,&stable.lock);
	//cprintf("Listening at port %d sucessful.\n",lport);
	release(&stable.lock);
	return 0;//zero for success
 
}

int
connect(int rport, const char* host) {

  
        struct socket *s;
	
	acquire(&stable.lock);
	int i;
	int lp=-1;
	for(i=0;i<NPORT;i++)
	{
		if(stable._ports[i]==0)//unused port found
		{
			lp=i;
			break;
		}
	}
	
	if(lp==-1)
	{
		cprintf("Unused port not found\n");
		goto failure;
	}
	int cs_ind=-1;
	int counter=0;
	for(s = stable.socket_arr; s < &stable.socket_arr[NSOCK]; s++)
	 {
		if(s->state==CLOSED )
		{
			cs_ind=counter;
		 	s->state=CONNECTING;
		 	break;
		 	
		}
		counter++;
	 }
	 
	 if(cs_ind==-1)
	 {
		cprintf("No more sockets can be opened(limit exceeded)\n");
		release(&stable.lock);
		return E_FAIL;
		//goto failure;
	 }
	
	 
	 
	 for(s = stable.socket_arr; s < &stable.socket_arr[NSOCK]; s++)
	 {
		if(s->state==LISTENING && s->local_port==rport )
		{
			
			stable._ports[lp]=1;
			stable.socket_arr[cs_ind].local_port=lp;
			stable.socket_arr[cs_ind].remote_port=rport;
			stable.socket_arr[cs_ind].state=CONNECTED;
			stable.socket_arr[cs_ind].buffer_empty=1;
			stable.socket_arr[cs_ind].ownerProcessID=myproc()->pid;
			s->state=CONNECTED;///////SERVER CONNECTED!!!!
			s->remote_port=lp;
			s->buffer_empty=1;
			//cprintf(" here Server port: %d\n",s->local_port);
			wakeup(s);
			release(&stable.lock);
			return lp;//successfully connected!!
		}
	 }
	 
failure:	
  release(&stable.lock);
  cprintf("Connection failed!!!\n");	
  return E_NOTFOUND;//connection failed!!!!
}

int
send(int lport, const char* data, int n) {

  int i;
  int rem_port=-1;
  acquire(&stable.lock);
  //cprintf("Inside send, data: %s\n",data);
  for(i=0;i<NSOCK;i++)
  {
  	if(stable.socket_arr[i].local_port==lport )
  	{
  		int current_process_id=myproc()->pid;
  		if(stable.socket_arr[i].ownerProcessID!=current_process_id)
  		{
  			cprintf("trying to send from wrong process\n");
  			release(&stable.lock);
  			return E_ACCESS_DENIED;
  		}
  		if(stable.socket_arr[i].state==CONNECTED)
  		{
  			rem_port=stable.socket_arr[i].remote_port;
  		}
  		else
  		{
	  		cprintf("Sending failed, local port not connected!!!\n");
	  		release(&stable.lock);
	  		return E_WRONG_STATE;
	  		//goto failure;
  		}
  	}

  }
  
  for(i=0;i<NSOCK;i++)
  {
  	if(stable.socket_arr[i].local_port==rem_port)
  	{
  		if(stable.socket_arr[i].buffer_empty==1)//server buffer empty
  		{
			strncpy(stable.socket_arr[i].buffer,data,n);
			
			//cprintf("from buffer inside send: %s\n",stable.socket_arr[i].buffer);
			stable.socket_arr[i].buffer_empty=0;
			wakeup(&stable.socket_arr[i]);//data has been written to buffer, so notify server
			goto success;
			
			
  		}
  		else//server buffer contains data
  		{
  		   	sleep(&stable.socket_arr[i],&stable.lock);//wait for it to be empty
  		   	strncpy(stable.socket_arr[i].buffer,data,n);//after waking up, write data to remote port buffer
  		   	//cprintf("from buffer inside send: %s\n",stable.socket_arr[i].buffer);
  		   	stable.socket_arr[i].buffer_empty=0;
  		   	goto success;
  		   	
  		}
  	}
  }

  release(&stable.lock);
  return E_NOTFOUND;//sending unsuccessful!!!
  
 success:
  release(&stable.lock);
  return 0;////sending successful
}


int
recv(int lport, char* data, int n) {

int i;
acquire(&stable.lock);
  for(i=0;i<NSOCK;i++)
  {
  	if(stable.socket_arr[i].local_port==lport)
  	{
  	      	int current_process_id=myproc()->pid;
  		if(stable.socket_arr[i].ownerProcessID!=current_process_id)
  		{
  			cprintf("trying to send from wrong process\n");
  			release(&stable.lock);
  			return E_ACCESS_DENIED;
  		}
  	    if(stable.socket_arr[i].state==CONNECTED){
  		if(stable.socket_arr[i].buffer_empty == 1)//if buffer does not contain data
  		{
  			sleep(&stable.socket_arr[i],&stable.lock);//wait for data to be written to it by client
  			strncpy(data,stable.socket_arr[i].buffer,n);//after waking up,read the data
  			stable.socket_arr[i].buffer[0]='\0';
  			//cprintf("from buffer inside recv: %s\n",stable.socket_arr[i].buffer);
  			stable.socket_arr[i].buffer_empty=1;//buffer is now empty
  			goto success;
  			
  		}
  		else//if buffer contains data
  		{
  			strncpy(data,stable.socket_arr[i].buffer,n);//read the data
  			stable.socket_arr[i].buffer[0]='\0';
  			//cprintf("from buffer inside recv: %s\n",stable.socket_arr[i].buffer);
  			stable.socket_arr[i].buffer_empty=1;//buffer is now empty
  			wakeup(&stable.socket_arr[i]);//data has been read from buffer, so notify client
  			goto success;
  		}

  	    }
  	    else
	    {
	  	cprintf("Receive failure, local port not connected!!!\n");	  		
	  	release(&stable.lock);
	  	return E_WRONG_STATE;
	    }
  		
  	}

  }
 
 	release(&stable.lock);
  	return E_NOTFOUND;//receiving unsuccessful!!!
 	 
 success: 
	release(&stable.lock);
  	return 0;//receiving successful!!!
}

int
disconnect(int lport) {
  int rem_port=-3;
  int i;
  acquire(&stable.lock);
  for(i=0;i<NSOCK;i++)
  {
  	if(stable.socket_arr[i].local_port==lport )
  	{ 
  	  	int current_process_id=myproc()->pid;
  		if(stable.socket_arr[i].ownerProcessID!=current_process_id)
  		{
  			cprintf("trying to send from wrong process\n");
  			release(&stable.lock);
  			return E_ACCESS_DENIED;
  		}
  	    if(stable.socket_arr[i].state==CONNECTED)
  	    {
  		rem_port=stable.socket_arr[i].remote_port;
  		stable.socket_arr[i].state=CLOSED;
  		stable.socket_arr[i].local_port=-1;
  		stable.socket_arr[i].remote_port=-1;
  	    }
  	    else
  	    {
  		cprintf("Local port not connected!!!\n");
  		release(&stable.lock);
  		return E_WRONG_STATE;
  		//goto failure;
  	    }
  		
  	}

  }
  if(rem_port==-3)
  {
  	cprintf("Local port not found in socket array!!!\n");
  	release(&stable.lock);
  	return E_NOTFOUND;
  	//goto failure;
  }
  for(i=0;i<NSOCK;i++)
  {
  	if(stable.socket_arr[i].local_port==rem_port)
  	{
  		
  		stable.socket_arr[i].state=CLOSED;
  		stable.socket_arr[i].local_port=-1;
  		stable.socket_arr[i].remote_port=-1;
  		goto success;
  		
  	}
  }
  release(&stable.lock);
  return E_NOTFOUND;//remote port not found in socket array
success:
   stable._ports[lport]=0;
   stable._ports[rem_port]=0;
   release(&stable.lock);
   return 0;//disconnecting successful!!!
}
