#include "types.h"
#include "user.h"

int
main(void)
{
 printf(1,"%d\n",listen(12));
 int cp=connect(12,"127");
 printf(1,"Client port: %d\n",cp);
//printf(1,"pid= %d\n",getpid());
    char buf[128];
    printf(1, "Client>> Enter text to send to server: ");
    gets(buf, sizeof(buf));

    buf[strlen(buf) - 1] = '\0'; // Eliminating the '\n'
    send(cp, buf, strlen(buf) + 1);

    char buf2[128];
    recv(12, buf2, sizeof(buf));
    printf(1, "Server>> Received: \"%s\"\n", buf2);


 exit();
}

